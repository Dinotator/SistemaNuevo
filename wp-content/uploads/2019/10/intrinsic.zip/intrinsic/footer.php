<?php
/**
* The template for displaying the footer.
*
* Contains the closing of the #content div and all content after
*
* @package Intrinsic
* @since 1.0
*/
?> 
    <?php intrinsic_get_template_part('footer'); ?>
    <?php wp_footer(); ?>
</body>
</html>
